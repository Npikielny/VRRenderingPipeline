//
//  ContentView.swift
//  Sample
//
//  Created by Noah Pikielny on 9/16/22.
//

import SwiftUI
import ShaderKit

struct ContentView: View {
    let view = MTKViewRepresentable(
        frame: CGRect(x: 0, y: 0, width: 200, height: 200),
        device: device
    )
    let timer = Timer.publish(every: 0.01, on: .main, in: .default).autoconnect()
    
    static let device = MTLCreateSystemDefaultDevice()!
    static let commandQueue = device.makeCommandQueue()!
    static let abe = Texture(Bundle.main.url(forResource: "abe_david ", withExtension: ".jpg")!.path)
    
    static let texture = abe.emptyCopy(usage: .renderTarget)
    
    @State var t: Double = 0
    
    var body: some View {
        view.onReceive(timer) {
            _ in draw(in: view)
            t += 0.01
        }
    }
    
    func draw(in view: MTKViewRepresentable) {
        guard let drawable = view.view.currentDrawable,
              let renderDescriptor = view.view.currentRenderPassDescriptor else { return }
        let operation = try! RenderPipeline(
            pipeline: .constructors("copyVert", "editImage", RenderPipelineDescriptor.texture(Self.texture)),
            fragmentTextures: [Self.abe],
            fragmentBuffers: [.init(Float(t))],
            renderPassDescriptor: RenderPassDescriptor.drawable
        )
        
        Task {
            try await RenderBuffer(presents: true) {
                operation
            }.execute(
                commandQueue: Self.commandQueue,
                drawable: drawable,
                renderDescriptor: renderDescriptor
            )
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
