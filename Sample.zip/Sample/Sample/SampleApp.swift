//
//  SampleApp.swift
//  Sample
//
//  Created by Noah Pikielny on 9/16/22.
//

import SwiftUI

@main
struct SampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
